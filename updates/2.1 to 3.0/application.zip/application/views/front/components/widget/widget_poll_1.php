<?php
	$this->load->view('front/components/poll/poll_option');
?>