<section class="page-section with-sidebar pad-t-15">
    <div class="container">
        <div class="row mar-lr--5">
            <!-- LEFT SIDEBAR -->
            <aside class="col-md-3 col-md-3 col-sm-12 col-xs-12 sidebar" id="sidebar">
                <?php include 'left_aside.php'; ?>
            </aside>
            <!-- /LEFT SIDEBAR -->

            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 content pad-lr-5" id="content">
                <?php include 'main_content.php'; ?>
            </div>
        </div>
    </div>
</section>