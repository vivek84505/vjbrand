<div id="content-container" style="padding-top:0px !important;">
    <div class="text-center pad-all">
        <div class="pad-ver">
            <center>
                <img class="img-responsive img-border" src="<?php echo base_url(); ?>uploads/styles/preview_<?php echo $type;?>_<?php echo $id;?>.jpg"  >
            </center>
        </div>
    </div>
</div>