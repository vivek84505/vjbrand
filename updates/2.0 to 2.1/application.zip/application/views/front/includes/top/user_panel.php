
        <!-- for tagsinput-->
        <link href="<?php echo base_url(); ?>template/back/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">
        <!-- for switchery -->
        <link href="<?php echo base_url(); ?>template/back/plugins/switchery/switchery.min.css" rel="stylesheet">
        <!-- for summernote -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>template/front/assets/plugins/summernote/summernote.css"
        <!-- for dataTables -->
        <link href="<?php echo base_url(); ?>template/front/assets/plugins/bootstrap/css/dataTables.bootstrap.min.css" rel="stylesheet">
        