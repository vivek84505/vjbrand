		<link href="<?php echo base_url();?>template/front/assets/plugins/owl-carousel2/assets/owl.carousel.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>template/front/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url(); ?>template/front/assets/js/share/jquery.share.css" />