		<link href="<?php echo base_url();?>template/front/assets/plugins/social_icons/social_icons.css" rel="stylesheet">
		<link href="<?php echo base_url();?>template/front/assets/plugins/owl-carousel2/assets/owl.carousel.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>template/front/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>template/front/assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet">