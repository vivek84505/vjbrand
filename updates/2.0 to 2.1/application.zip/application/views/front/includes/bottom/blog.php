<script src="<?php echo base_url();?>template/front/assets/plugins/owl-carousel2/owl.carousel.min.js"></script>
<script src="<?php echo base_url();?>template/front/assets/plugins/countdown/jquery.plugin.min.js"></script>
<script src="<?php echo base_url();?>template/front/assets/plugins/countdown/jquery.countdown.min.js"></script>